public class Konto {
    private double kontostand;
    private String inhaber;
    
    private int x = 0;
    private boolean b;
    
    public Konto(String arg) {
        this.kontostand = 0;
        if (arg != "" && arg != "leer") { 
            this.inhaber = arg;
            this.x++;
        } else {
            this.inhaber = "Inhaber" + this.x;
        }
    }
    
    public void einzahlen(double betrag) {
        if (this.betrag > 0) {
            this.kontostand += betrag;
            this.b = true;
        } else {
            this.b = false;
        }
    }
    
    public void abheben(double betrag) {
        if (this.betrag - this.kontostand > 0) {
            this.kontostand -= betrag;
            this.b = true;
        } else {
            this.b = false;
        }
    }
    
    public void zeigeKonto() {
        System.out.println("Inhaber: " + this.inhaber);
        System.out.println("Kontostand: " + this.kontostand);
    }
}