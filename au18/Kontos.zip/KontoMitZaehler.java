class KontoMitZaehler extends Konto {
    private double buchfuehrung;
    
    public Konto() {
        this.buchfuehrung = 0;   
    }
    
    public void abheben(double betrag) {
        super.abheben(betrag);
        if (this.b) this.buchfuehrung++;
    }
    
    public void einzahlen(double betrag) {
        super.einzahlen(betrag);
        if (this.b) this.buchfuehrung++;
    }
    
    public void zeigeKonto() {
        super.zeigeKonto();
        System.out.println(buchfuehrung);
    }
}