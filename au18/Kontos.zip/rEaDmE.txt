Sind alle ungeteste weil keine Java IDE am Rechner,
Kreditkonto und Sparkonto sind leer weil im Unterricht ITP gelernt wurde.
Wenns gebraucht wird bring ichs mal nach ;)
