class Kreditkonto extends KontoMitAuszug {
 // Way too lazy
}