class SparKonto extends KontoMitAuszug {
   // Way too lazy 
}