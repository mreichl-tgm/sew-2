public class KontoMitAuszug extends Konto {
    private String[] buchungsliste;
    
    public Konto() {
        this.buchungsliste = new String[0];
    }
    
    public void abheben(String betrag) {
        super.abheben(betrag);
        if (this.b) addToAry(true, betrag);
    }
    
    public void einzahlen(String betrag) {
        super.einzahlen(betrag);
        if (this.b) addToAry(false, betrag);
    }
    
    private void addToAry(boolean positiv, double betrag) {
        String[] buffer = new String[buchungsliste.length + 1];
        for (int i = 0; i < this.buchungsliste.length; i++) {
            buffer[i] = buchungsliste[i];
        }
        
        if (positiv) {
            buffer[buchungsliste.length] = betrag;
        } else {
            buffer[buchungsliste.length] = betrag * -1;
        }
        
        this.buchliste = buffer;
    }
     
    public void zeigeKontoAuszug() {
        System.out.println(this.buchliste);
        this.buchliste = new String[0];
    }
}