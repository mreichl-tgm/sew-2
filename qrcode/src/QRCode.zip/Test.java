public class Test {
    public static void main(String[] args) {
        QRControl c = new QRControl();
    }
}